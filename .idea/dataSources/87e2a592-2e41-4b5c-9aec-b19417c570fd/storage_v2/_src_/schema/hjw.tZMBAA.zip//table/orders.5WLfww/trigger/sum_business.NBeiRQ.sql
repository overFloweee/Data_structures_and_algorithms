create definer = root@`%` trigger sum_business
    before insert
    on orders
    for each row
BEGIN
    UPDATE businesses
    SET sales = IFNULL(sales, 0) + NEW.amount
    WHERE id = NEW.business_id;
end;

